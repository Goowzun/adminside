<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$hook = Luthier\Hook::getHooks();

$hook['pre_system'][] = function() {
	$dotenv = Dotenv\Dotenv::create(FCPATH);
	$dotenv->load();
};