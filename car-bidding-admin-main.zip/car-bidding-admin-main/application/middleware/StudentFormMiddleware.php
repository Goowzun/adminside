<?php
# application/middleware/TestMiddleware.php

use Luthier\Utils;
use Luthier\RouteBuilder;

class StudentFormMiddleware implements Luthier\MiddlewareInterface
{
    public function run($args)
    {
        
    }
}