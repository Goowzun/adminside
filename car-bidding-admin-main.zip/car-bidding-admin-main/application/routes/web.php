<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function default_resource($name, $group, $controller=null, $middlewares=[], $extend_resource=null)
{
    $controller = $controller ? $controller : str_replace(' ', '', ucwords(str_replace(['-'], ' ', $name))).'Controller';

    Route::group($group, ['middleware' => $middlewares], function () use ($name, $group, $controller, $extend_resource)
    {
        Route::get('/', $controller.'@index', ['middleware' => ['SmartyMiddleware']])->name($name);

        Route::get('new', $controller.'@new', ['middleware' => ['SmartyMiddleware']])->name($name.'.new');

        Route::post('/', $controller.'@create')->name($name.'.create');

        Route::get('{num:id}', $controller.'@edit', ['middleware' => ['SmartyMiddleware']])->name($name.'.edit');

        Route::post('{num:id}', $controller.'@update')->name($name.'.update');

        Route::delete('{num:id}', $controller.'@delete')->name($name.'.delete');

        if ($extend_resource) $extend_resource($name, $group, $controller);
    });
}

Route::get('pwd', function ()
{
    json_response(true, ['password' => encryptPassword(get('pwd') ?? '12345')]);
});

Route::set('404_override', function()
{
    show_404();
});

Route::set('translate_uri_dashes', FALSE);

Route::group('/', function ()
{
    $name = 'login';
    $controller = 'LoginController';

    Route::group('/', ['middleware' => ['SessionMiddleware']], function () use ($name, $controller)
    {
        Route::get('login', $controller.'@login', ['middleware' => ['SmartyMiddleware']])->name($name);

        Route::post('login', $controller.'@login_check')->name($name.'.check');

        Route::get('logout', $controller.'@logout')->name('logout');
    });
});

Route::group('/', ['middleware' => ['SessionMiddleware', 'CheckLoginMiddleware']], function()
{
    Route::group('/', function ()
    {
        $name = 'home';
        $controller = 'HomeController';

        Route::get('/', $controller.'@home', ['middleware' => ['SmartyMiddleware']])->name($name);

        Route::get('about-us', $controller.'@about_us', ['middleware' => ['SmartyMiddleware']])->name($name.'.about-us');
    });

    Route::group('profile', function ()
    {
        $name = 'profile';
        $controller = 'ProfileController';

        Route::get('/', $controller.'@index', ['middleware' => ['SmartyMiddleware']])->name($name);

        Route::post('/', $controller.'@update_user_profile')->name($name.'.update-user');
        
        Route::post('password', $controller.'@password')->name($name.'.password');
    });

    default_resource('admin', 'admins', null, ['AdminMiddleware']);

    default_resource('brand', 'brands', null, ['AdminMiddleware']);

    default_resource('model', 'models', null, ['AdminMiddleware']);

    default_resource('product', 'products', null, ['AdminMiddleware']);
});