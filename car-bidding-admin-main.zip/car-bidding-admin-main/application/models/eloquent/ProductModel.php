<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use \Illuminate\Database\Capsule\Manager as DB;

class ProductModel extends BaseModel
{
	protected $table = 'products';

	protected $appends = ['date_created', 'date_updated', 'brand', 'model'];

	protected $hidden = ['created_at', 'updated_at'];

	public function rel_brand()
	{
		return $this->hasOne(BrandModel::class, 'id', 'brand_id');
	}	

	public function rel_model()
	{
		return $this->hasOne(ModelModel::class, 'id', 'model_id');
	}

	public function getBrandAttribute()
	{
		return $this->rel_brand ? 
			$this->rel_brand->brand : null;
	}	

	public function getModelAttribute()
	{
		return $this->rel_model ? 
			$this->rel_model->model : null;
	}

}