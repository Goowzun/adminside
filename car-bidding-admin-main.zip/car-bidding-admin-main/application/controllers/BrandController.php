<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BrandController extends CI_Controller 
{
	private $parent_route = 'brand';

	private $templates_dir = 'brand';

	function __construct()
	{
		parent::__construct();

		$this->table_model = BrandModel::class;

		$this->table_row = null;
	}
	public function index()
	{
		$table = $this->table_model::get(); 

		$table->each(function ($item, $key)
		{
			ci()->add_table_row_action($item);
		});

		$this->sm->assign('table_data', $table->toJson());

		$this->sm->assign('parent_route', $this->parent_route);

		$this->sm->display($this->templates_dir.'/table.tpl');
	}
	public function new()
	{
		# $this->set_masterdata();

		$this->sm->assign('parent_route', $this->parent_route);

		$html = $this->sm->fetch($this->templates_dir.'/entry.tpl');

		json_response(true, ['html' => $html]);
	}
	private function delete_files()
	{
		$files = $_POST['delete_files'] ?? [];

		foreach ($files as $file)
		{
			$img = $this->table_model::find($file);
			if ($img)
			{
				$img->image = null;
				$img->save();
			}
		}
	}
	public function create()
	{	
		$this->set_table_row();

		$this->set_table_row_fields();

		$this->validate_table_row_fields();

		$this->table_row->save();

		$this->add_table_row_action();

		json_response(true, ['data' => $this->table_row]);
	}
	public function edit($id)
	{
		$this->set_table_row($id);

		$this->sm->assign('row', $this->table_row);

		$this->set_masterdata();

		$this->sm->assign('parent_route', $this->parent_route);

		$html = $this->sm->fetch($this->templates_dir.'/entry.tpl');

		json_response(true, ['html' => $html]);
	}
	public function update()
	{
		$this->set_table_row(post('id'));

		$this->set_table_row_fields();

		$this->validate_table_row_fields();

		$this->table_row->save();

		$this->delete_files();

		$this->add_table_row_action();

		json_response(true, ['data' => $this->table_row]);
	}
	public function delete($id)
	{
		$this->set_table_row($id);

		$this->table_row->delete();

		json_response(true, ['message' => 'Record has been deleted']);
	}
	private function set_table_row($id=null)
	{
		if (is_null($id))
		{
			$this->table_row = new $this->table_model;

			return;
		}

		$this->table_row = $this->table_model::find($id);

		if (!$this->table_row) json_response(false, ['message' => 'Invalid request']);
	}
	private function set_table_row_fields()
	{
		$this->table_row->brand = post('brand', 'trim');

		$this->table_row->image = post('image', 'trim');

		$this->table_row->image = $this->table_row->image ? $this->table_row->image : null;
	}
	private function validate_table_row_fields()
	{
		$this->load->library('form_validation');

		$this->form_validation->set_rules('brand', 'brand', [
			'required',
			BrandModel::is_unique('brand')
		]);

		$this->form_validation->set_data($this->table_row->toArray());

		if ($this->form_validation->run() == FALSE)
		{
			json_response(false, ['message' => implode('</br>', $this->form_validation->error_array())]);
		}
	}
	private function add_table_row_action(&$table_row=null)
	{	
		if (is_null($table_row)) $table_row =& $this->table_row;

		$items = [];

		$items[] = el('a.dropdown-item.edit-row[href=#]', [
			el('i.ph-pencil-simple-line.me-2'),
			'Edit'
		]);

		$items[] = el('a.dropdown-item.delete-row[href=#]', [
			el('i.ph-trash.me-2'),
			'Delete'
		]);

		$table_row->action = el('.d-inline-flex > .dropdown', [
			el('a.text-body.actions[href=#][data-bs-toggle=dropdown]', [
				el('i.ph-list')
			]),
			el('.dropdown-menu dropdown-menu-end', $items)
		]);

		$table_row->action_edit = route($this->parent_route.'.edit', $table_row->id);

		$table_row->action_update = route($this->parent_route.'.update', $table_row->id);

		$table_row->action_delete = route($this->parent_route.'.delete', $table_row->id);
	}
	private function set_masterdata()
	{
		$images = $this->table_model::where('id', $this->table_row->id)
		->whereNotNull('image')
		->get();

		$images->each(function ($item, $key)
		{
			$url = $item->image;

			$url = str_replace('/image/upload/', '/image/upload/w_1000,ar_1:1,c_fill,g_auto,e_art:hokusai/', $url);

			$html = '<div class="card mb-3 me-3 img-card">
				<div class="card-img-actions m-1">
					<img class="card-img img-preview img-upload-preview" src="@URL" alt="">
					<div class="card-img-actions-overlay card-img">
						<a href="#" class="btn btn-outline-white btn-icon rounded-pill" img-delete data-id="@ID" data-public-id="">
							<i class="ph-trash"></i>
						</a>
					</div>
				</div>
			</div>';

			$item->image = str_replace('@URL', $url, $html);
			$item->image = str_replace('@ID', $item->id, $item->image);
		});

		$this->sm->assign([
			'images' => $images
		]);
	}
}