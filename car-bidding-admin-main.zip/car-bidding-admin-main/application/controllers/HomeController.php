<?php
defined('BASEPATH') or exit('No direct script access allowed');

use \Illuminate\Database\Capsule\Manager as DB;

class HomeController extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	public function home()
	{
		$this->sm->display('home/home.tpl');
	}
}
